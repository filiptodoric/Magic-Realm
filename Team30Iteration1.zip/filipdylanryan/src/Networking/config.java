package Networking;
public class config {
    public static final int PORT = 9001;
    public static final String HOST = "192.168.0.12";
    public static final int MAX_PLAYERS = 6;
    public static final int MIN_PLAYERS = 1;
}
