package Networking;

public class ServerConfig {

	// static int which keeps track of the number of days left
	// users will select all of their actions for the day and 
	// when they send the command it will decrement the int
	public static int numberOfDaysRemaining = 28;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
